#include	<stdlib.h>
#include	"my.h"
#include	"myirc_client.h"

void		*xmalloc(int size)
{
  void		*return_v;

  return_v = malloc(size);
  if (return_v == NULL)
    exit_msg(MALLOC_ERROR, MALLOC_MSG);
  return (return_v);
}
