#include		<stdlib.h>

int			ischar(char str, char *patern)
{
  int			i;

  i = -1;
  while (patern[++i])
    if (patern[i] == str)
      return (1);
  return (0);
}

int			isstr(char *str, char *patern)
{
  int			i;

  i = -1;
  while (str[++i])
    {
      if (!ischar(str[i], patern))
	return (0);
    }
  return (1);
}
