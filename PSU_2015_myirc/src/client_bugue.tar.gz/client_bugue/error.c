#include	<stdlib.h>
#include	<stdio.h>
#include	"myirc_client.h"

int		check_serv(t_client *client)
{
  if (client->server.connected != 1)
    return (-1);
  return (1);
}

void		exit_msg(int nbr, char *msg)
{
  dprintf(2, "%s\n", msg);
  exit(nbr);
}
