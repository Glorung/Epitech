#include	<stdlib.h>
#include	<stdio.h>
#include	"myirc_client.h"

int		xsend(t_client *client, char **tab)
{
  tab = tab;
  client = client;
  printf("Error: Not dev yet...");
  return (-1);
}
