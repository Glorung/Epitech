#include	<stdlib.h>
#include	<stdio.h>
#include	"myirc_client.h"

int		xnick(t_client *client, char **tab)
{
  if (check_serv(client) == -1)
    return (-1);
  if (tab[1] && !tab[2])
    dprintf(FD[1], "NICK %s\n\r", tab[1]);
  else
    {
      add_to_window("Usage: /nick NAME\n");
      return (-1);
    }
  return (0);
}
