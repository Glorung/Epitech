#include	<stdlib.h>
#include	<stdio.h>
#include	<curses.h>
#include	<ncurses.h>
#include	"myirc_client.h"

int		xquit(t_client *client, char **tab)
{
  echo();
  endwin();
  if (client->server.connected == 1)
    {
      close(FD[1]);
      FD[1] = -1;
    }
  exit(0);
  tab = tab;
  return (0);
}
