#include	<stdlib.h>
#include	<stdio.h>
#include	<string.h>
#include	"myirc_client.h"
#include	"my.h"

int		notice(t_client *client, char **tab)
{
  int		i;
  int		j;
  char		**tab2;
  char		**tab3;

  tab2 = my_strtotab(strdup(client->serv_input), "\n");
  i = -1;
  add_to_window("- ");
  add_to_window(client->server.ip);
  add_to_window(" -");
  while (tab2[++i] != NULL)
    {
      tab3 = my_strtotab(tab2[i], " ");
      j = 3;
      if (tab3[0] && tab3[1] && tab3[2] && tab3[3])
	{
	  if (tab3[j][0] == ':')
	    tab3[j][0] = ' ';
	  while (tab3[j] != NULL && tab3[j + 1] != NULL)
	    {
	      add_to_window(tab3[j++]);
	      add_to_window(" ");
	    }
	}
      if (tab3[j])
	add_to_window(tab3[j]);
      printf("\n");
    }
  add_to_window("-----\n");
  tab = tab;
  return (0);
}
