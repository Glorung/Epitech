#include	<stdlib.h>
#include	<stdio.h>
#include	"myirc_client.h"

int		xaccept(t_client *client, char **tab)
{
  tab = tab;
  client = client;
  add_to_window("Error: Not dev yet...");
  return (-1);
}
