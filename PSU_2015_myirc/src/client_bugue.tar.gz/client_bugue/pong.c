#include	<stdlib.h>
#include	<stdio.h>
#include	"myirc_client.h"

int		pong(t_client *client, char **tab)
{

  printf("Debug: Goto pong\n");
  if (tab[0] && tab[1] && !tab[2])
    dprintf(FD[1], "PONG %s\n\r", tab[1]);
  else
    {
      printf("Error pong\n");
      return (-1);
    }
  return (0);
}
