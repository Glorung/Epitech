#include	<stdlib.h>
#include	<stdio.h>
#include	<curses.h>
#include	<ncurses.h>
#include	<string.h>
#include	"ncurses_genshlib.h"
#include	"my.h"
#include	"myirc_client.h"

void		get_entry_display(t_pos pos, char *txt, int cursor)
{
  int   i;

  i = -1;
  while (++i != pos.end_x)
    mvprintw(pos.begin_y, i, " ");
  mvprintw(pos.begin_y, pos.begin_x, "%s ", txt);
  move(pos.begin_y, cursor);
  refresh();
}

void			get_entry_move(int input, int *cursor)
{
  if (input == UP_ARROW || input == DOWN_ARROW)
    return ;
  else if (input == LEFT_ARROW)
    {
      if (*cursor != 0)
	*cursor -= 1;
    }
  else if (input == RIGHT_ARROW)
    *cursor += 1;
}

char			*get_entry(t_pos pos)
{
  static char		*txt = NULL;
  static int		cursor = 1;
  char          *return_v;
  int			input;

  if (txt == NULL)
    {
      txt = xmalloc(sizeof(char) * 4096);
      txt[0] = '\0';
    }
    input = getch();
  if (input == ENTER && txt[0] != '\0')
  {
    dprintf(2, "Get entry end [%s]\n", txt);
    return_v = txt;
    txt = NULL;
    cursor = 1;
    return (return_v);
  }
  if (input != ENTER)
    txt = get_entry_use(pos, txt, input, &cursor);
  return (NULL);
}
