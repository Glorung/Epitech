#include	<stdlib.h>
#include	<stdio.h>
#include	<curses.h>
#include	<ncurses.h>
#include	<string.h>
#include	"ncurses_genshlib.h"
#include	"my.h"
#include	"myirc_client.h"

static void		add_char_from(char *str, int input, int *cursor)
{
  int			i;

  if (input == -1)
    return ;
  if (str[0] == '\0')
  {
    str[0] = input;
    str[1] = '\0';
    return ;
  }
  i = strlen(str);
  str[i] = input;
  str[i + 1] = '\0';
  *cursor += 1;
}

static void		remove_char_from(char *str, int *cursor)
{
  int			i;

  i = strlen(str);
  if (i != 0)
    str[i - 1] = '\0';
  if (*cursor != 0)
    *cursor -= 1;
}

int			is_arrow(int input)
{
  if (input == UP_ARROW)
    return (1);
  else if (input == DOWN_ARROW)
    return (2);
  else if (input == LEFT_ARROW)
    return (3);
  else if (input == RIGHT_ARROW)
    return (4);
  return (0);
}

char    *get_entry_use(t_pos pos, char *txt, int input, int *cursor)
{
  if (is_arrow(input))
    get_entry_move(input, cursor);
  else if (input == BACKSPACE)
    remove_char_from(txt, cursor);
  else
    add_char_from(txt, input, cursor);
  get_entry_display(pos, txt, *cursor);
  return (txt);
}
