#include  <stdlib.h>
#include  <curses.h>
#include  <ncurses.h>
#include  <string.h>
#include  <unistd.h>
#include  "my.h"
#include  "myirc_client.h"
#include  "ncurses_genshlib.h"

char      **init_display(t_pos pos)
{
  int     i;
  int     x;
  int     y;
  char    **return_v;

  x = pos.end_x - pos.begin_x;
  y = (pos.end_y - pos.begin_y) + 1;
  return_v = xmalloc(sizeof(char *) * (x + 1));
  i = -1;
  while (++i != x)
    return_v[i] = xmalloc(sizeof(char) * (y + 1));
  i = -1;
  while (++i != x)
    return_v[i][0] = '\0';
  return_v[i] = NULL;
  return (return_v);
}

char		*remove_begin_str_to(char *str, char to)
{
  int		i;
  int		j;

  i = -1;
  j = 0;
  while (str[++i] != '\0' && str[i] != to);
  if (str[i] == '\0')
    return (NULL);
  while (str[++i])
    str[j++] = str[i];
  str[j] = '\0';
  return (str);
}

void            add_to_window(char *new)
{
  static char   *str = NULL;
  char		**tab;
  int		i;

  if (new == NULL || new[0] == '\0')
    return ;
  if ((str == NULL || str[0] == '\0')
      && (str = xmalloc(sizeof(char) * 4096)) != NULL)
    str[0] = '\0';
  dprintf(2, "before strcat [%s][%s]\n", str, new);
  str = strcat(str, new);
  if (ischar('\n', new) && (tab = my_strtotab(strdup(str), "\n")) != NULL
      && tab[0] != NULL)
    {
      display_window(tab[0]);
      str = remove_begin_str_to(str, '\n');
      add_to_window(str);
      i = 0;
      while (tab[++i] != NULL)
	str = strcat(str, tab[i]);
      return ;
      my_free_tab(tab);
    }
}

char		**pushtab(char **txt, char *str)
{
  int		i;

  i = -1;
  while (txt[++i] != NULL)
    {
      if (txt[i + 1] != NULL)
	txt[i] = txt[i + 1];
    }
  txt[i - 1] = str;
  return (txt);
}

void            display_window(char *str)
{
  static char    **txt = NULL;
  static int     line = 0;
  int            i;
  t_pos   pos;

  pos.begin_x = 0;
  pos.end_x = COLS;
  pos.begin_y = 0;
  pos.end_y = LINES - 3;
  if (txt == NULL)
    txt = init_display(pos);
  i = -1;
  if (line != pos.end_y)
    txt[line++] = str;
  if (line == pos.end_y)
      txt = pushtab(txt, str);
  while (txt[++i] != NULL)
    mvprintw(pos.begin_y++, pos.begin_x, "%s", txt[i]);
  i = -1;
  while (++i != COLS)
    mvprintw(LINES - 2, i, "-");
  refresh();
}
